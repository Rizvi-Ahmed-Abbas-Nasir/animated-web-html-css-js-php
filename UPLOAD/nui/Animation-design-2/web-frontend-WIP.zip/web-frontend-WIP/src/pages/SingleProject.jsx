import React from "react";
import RouteTransition from "../components/RouteTransition";

const SingleProject = () => {
  return (
    <RouteTransition>
      <div>Single Project</div>
    </RouteTransition>
  );
};

export default SingleProject;
